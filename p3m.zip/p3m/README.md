# 1550-proj3
3/28/2018: part 1 is finished, edited files a, b, c
1. it knows based on the position of the reference to the end of the linked list of pages
2. it uses a global variable kmem and run structs
3. these are global
4. walkpgdir takes a virtual address along with the proc pagetable and returns a physical address
